<?php
/*
Plugin Name: Shopify Products Display
Plugin URI: https://yourwebsite.com/
Description: Display Shopify products in WordPress using shortcodes and custom post types.
Version: 1.0.0
Author: Your Name
Author URI: https://yourwebsite.com/
License: GPL-2.0+
Text Domain: shopify-products-display
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SHOPIFY_PRODUCTS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SHOPIFY_PRODUCTS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SHOPIFY_PRODUCTS_VERSION', '1.0.0');

// Include required files
require_once SHOPIFY_PRODUCTS_PLUGIN_DIR . 'includes/class-shopify-products-api.php';
require_once SHOPIFY_PRODUCTS_PLUGIN_DIR . 'includes/class-shopify-products-cpt.php';
require_once SHOPIFY_PRODUCTS_PLUGIN_DIR . 'includes/class-shopify-products-shortcode.php';

class Shopify_Products_Display {

    public function __construct() {
        // Initialize all components
        $this->init();
    }

    public function init() {
        // Register activation and deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));

        // Initialize components
        new Shopify_Products_CPT();
        new Shopify_Products_Shortcode();
        new Shopify_Products_API();

        // Load assets
        add_action('wp_enqueue_scripts', array($this, 'load_assets'));
        add_action('admin_enqueue_scripts', array($this, 'load_admin_assets'));
    }

    public function activate() {
        // Flush rewrite rules on activation
        flush_rewrite_rules();
    }

    public function deactivate() {
        // Flush rewrite rules on deactivation
        flush_rewrite_rules();
    }

    public function load_assets() {
        // Frontend CSS
        wp_enqueue_style(
            'shopify-products-style',
            SHOPIFY_PRODUCTS_PLUGIN_URL . 'assets/css/style.css',
            array(),
            SHOPIFY_PRODUCTS_VERSION
        );

        // Frontend JS
        wp_enqueue_script(
            'shopify-products-script',
            SHOPIFY_PRODUCTS_PLUGIN_URL . 'assets/js/script.js',
            array('jquery'),
            SHOPIFY_PRODUCTS_VERSION,
            true
        );
    }

    public function load_admin_assets($hook) {
add_action('admin_enqueue_scripts', array($this, 'load_admin_assets'));
if ('shopify_products_settings' !== $hook) {
            return;
        }

        // Admin CSS
        wp_enqueue_style(
            'shopify-products-admin-style',
            SHOPIFY_PRODUCTS_PLUGIN_URL . 'assets/css/admin-style.css',
            array(),
            SHOPIFY_PRODUCTS_VERSION
        );

        // Admin JS
        wp_enqueue_script(
            'shopify-products-admin-script',
            SHOPIFY_PRODUCTS_PLUGIN_URL . 'assets/js/admin-script.js',
            array('jquery'),
            SHOPIFY_PRODUCTS_VERSION,
            true
        );
    }
}

// Initialize the plugin
new Shopify_Products_Display();