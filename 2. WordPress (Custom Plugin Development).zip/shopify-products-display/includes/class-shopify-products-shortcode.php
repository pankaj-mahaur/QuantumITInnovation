<?php
if (!defined('ABSPATH')) {
    exit;
}

class Shopify_Products_Shortcode {

    public function __construct() {
        add_shortcode('shopify_products', array($this, 'render_shortcode'));
        add_action('wp_ajax_shopify_products_filter', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_nopriv_shopify_products_filter', array($this, 'ajax_filter_products'));
    }

    public function render_shortcode($atts) {
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'count'      => '12',
            'columns'    => '4',
            'orderby'    => 'date',
            'order'      => 'DESC',
            'ids'        => '',
            'category'   => '',
            'tag'        => '',
            'vendor'     => '',
            'pagination' => 'true',
            'style'      => 'grid', // grid, list, masonry
        ), $atts, 'shopify_products');

        // Build query args
        $args = array(
            'post_type'      => 'shopify_product',
            'posts_per_page' => intval($atts['count']),
            'orderby'        => $atts['orderby'],
            'order'          => $atts['order'],
        );

        // Handle IDs
        if (!empty($atts['ids'])) {
            $args['post__in'] = array_map('intval', explode(',', $atts['ids']));
        }

        // Handle meta queries
        $meta_query = array();

        if (!empty($atts['vendor'])) {
            $meta_query[] = array(
                'key'     => '_shopify_product_vendor',
                'value'   => $atts['vendor'],
                'compare' => '=',
            );
        }

        if (!empty($atts['tag'])) {
            $meta_query[] = array(
                'key'     => '_shopify_product_tags',
                'value'   => $atts['tag'],
                'compare' => 'LIKE',
            );
        }

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }

        // Handle taxonomy query for product type (as category)
        if (!empty($atts['category'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_type',
                    'field'    => 'slug',
                    'terms'    => $atts['category'],
                ),
            );
        }

        // Enqueue scripts and styles
        wp_enqueue_style('shopify-products-style');
        wp_enqueue_script('shopify-products-script');

        // Localize script for AJAX
        wp_localize_script('shopify-products-script', 'shopify_products_vars', array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce'   => wp_create_nonce('shopify_products_nonce'),
        ));

        // Start output buffering
        ob_start();

        // Get products
        $products = new WP_Query($args);

        // Display products
        if ($products->have_posts()) :
            $column_class = 'shopify-product-col-' . $atts['columns'];
            $style_class = 'shopify-product-style-' . $atts['style'];
            ?>
            <div class="shopify-products-container <?php echo esc_attr($column_class); ?> <?php echo esc_attr($style_class); ?>">
                <?php while ($products->have_posts()) : $products->the_post(); ?>
                    <?php $this->render_product(get_the_ID()); ?>
                <?php endwhile; ?>
            </div>

            <?php if ($atts['pagination'] === 'true' && $products->max_num_pages > 1) : ?>
                <div class="shopify-products-pagination">
                    <?php
                    echo paginate_links(array(
                        'base'    => str_replace(999999999, '%#%', esc_url(get_pagenum_link(999999999))),
                        'format'  => '?paged=%#%',
                        'current' => max(1, get_query_var('paged')),
                        'total'   => $products->max_num_pages,
                    ));
                    ?>
                </div>
            <?php endif; ?>
            
            <?php wp_reset_postdata(); ?>
        <?php else : ?>
            <p class="shopify-products-not-found"><?php _e('No products found.', 'shopify-products-display'); ?></p>
        <?php endif;

        // Return the buffered content
        return ob_get_clean();
    }

    public function render_product($product_id) {
        $product = get_post($product_id);
        $price = get_post_meta($product_id, '_shopify_product_price', true);
        $compare_at_price = get_post_meta($product_id, '_shopify_product_compare_at_price', true);
        $vendor = get_post_meta($product_id, '_shopify_product_vendor', true);
        $product_type = get_post_meta($product_id, '_shopify_product_type', true);
        $tags = get_post_meta($product_id, '_shopify_product_tags', true);
        $shopify_link = get_post_meta($product_id, '_shopify_product_link', true);
        $variants = json_decode(get_post_meta($product_id, '_shopify_product_variants', true), true);
        ?>
        <div class="shopify-product">
            <div class="shopify-product-image">
                <a href="<?php echo esc_url($shopify_link); ?>" target="_blank" rel="noopener noreferrer">
                    <?php if (has_post_thumbnail($product_id)) : ?>
                        <?php echo get_the_post_thumbnail($product_id, 'medium'); ?>
                    <?php else : ?>
                        <img src="<?php echo esc_url(plugins_url('assets/images/placeholder.png', SHOPIFY_PRODUCTS_PLUGIN_DIR . 'shopify-products-display.php')); ?>" alt="<?php echo esc_attr($product->post_title); ?>">
                    <?php endif; ?>
                </a>
            </div>
            
            <div class="shopify-product-details">
                <h3 class="shopify-product-title">
                    <a href="<?php echo esc_url($shopify_link); ?>" target="_blank" rel="noopener noreferrer">
                        <?php echo esc_html($product->post_title); ?>
                    </a>
                </h3>
                
                <div class="shopify-product-price">
                    <?php if (!empty($compare_at_price) && $compare_at_price > $price) : ?>
                        <span class="shopify-product-compare-price"><?php echo esc_html($this->format_price($compare_at_price)); ?></span>
                        <span class="shopify-product-sale-price"><?php echo esc_html($this->format_price($price)); ?></span>
                    <?php else : ?>
                        <span class="shopify-product-regular-price"><?php echo esc_html($this->format_price($price)); ?></span>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($vendor)) : ?>
                    <div class="shopify-product-vendor"><?php echo esc_html($vendor); ?></div>
                <?php endif; ?>
                
                <div class="shopify-product-actions">
                    <a href="<?php echo esc_url($shopify_link); ?>" class="button shopify-product-button" target="_blank" rel="noopener noreferrer">
                        <?php _e('View Product', 'shopify-products-display'); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
    }

    public function ajax_filter_products() {
        check_ajax_referer('shopify_products_nonce', 'nonce');

        $args = array(
            'post_type'      => 'shopify_product',
            'posts_per_page' => isset($_POST['count']) ? intval($_POST['count']) : 12,
            'orderby'        => isset($_POST['orderby']) ? sanitize_text_field($_POST['orderby']) : 'date',
            'order'          => isset($_POST['order']) ? sanitize_text_field($_POST['order']) : 'DESC',
        );

        // Handle meta queries
        $meta_query = array();

        if (!empty($_POST['vendor'])) {
            $meta_query[] = array(
                'key'     => '_shopify_product_vendor',
                'value'   => sanitize_text_field($_POST['vendor']),
                'compare' => '=',
            );
        }

        if (!empty($_POST['tag'])) {
            $meta_query[] = array(
                'key'     => '_shopify_product_tags',
                'value'   => sanitize_text_field($_POST['tag']),
                'compare' => 'LIKE',
            );
        }

        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }

        // Handle taxonomy query for product type (as category)
        if (!empty($_POST['category'])) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_type',
                    'field'    => 'slug',
                    'terms'    => sanitize_text_field($_POST['category']),
                ),
            );
        }

        $products = new WP_Query($args);

        ob_start();

        if ($products->have_posts()) :
            while ($products->have_posts()) : $products->the_post();
                $this->render_product(get_the_ID());
            endwhile;
        else :
            echo '<p class="shopify-products-not-found">' . __('No products found.', 'shopify-products-display') . '</p>';
        endif;

        wp_reset_postdata();

        $output = ob_get_clean();

        wp_send_json_success(array(
            'html' => $output,
            'max_num_pages' => $products->max_num_pages,
        ));
    }

    private function format_price($price) {
        return '$' . number_format(floatval($price), 2);
    }
}