<?php
if (!defined('ABSPATH')) {
    exit;
}

class Shopify_Products_CPT {

    public function __construct() {
        add_action('init', array($this, 'register_custom_post_type'));
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_meta_data'));
    }

    public function register_custom_post_type() {
        $labels = array(
            'name'               => __('Shopify Products', 'shopify-products-display'),
            'singular_name'      => __('Shopify Product', 'shopify-products-display'),
            'menu_name'          => __('Shopify Products', 'shopify-products-display'),
            'name_admin_bar'     => __('Shopify Product', 'shopify-products-display'),
            'add_new'            => __('Add New', 'shopify-products-display'),
            'add_new_item'       => __('Add New Shopify Product', 'shopify-products-display'),
            'new_item'           => __('New Shopify Product', 'shopify-products-display'),
            'edit_item'         => __('Edit Shopify Product', 'shopify-products-display'),
            'view_item'         => __('View Shopify Product', 'shopify-products-display'),
            'all_items'         => __('All Shopify Products', 'shopify-products-display'),
            'search_items'      => __('Search Shopify Products', 'shopify-products-display'),
            'parent_item_colon' => __('Parent Shopify Products:', 'shopify-products-display'),
            'not_found'         => __('No Shopify products found.', 'shopify-products-display'),
            'not_found_in_trash' => __('No Shopify products found in Trash.', 'shopify-products-display')
        );

        $args = array(
            'labels'             => $labels,
            'public'            => true,
            'publicly_queryable' => true,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'query_var'         => true,
            'rewrite'           => array('slug' => 'shopify-product'),
            'capability_type'    => 'post',
            'has_archive'      => true,
            'hierarchical'      => false,
            'menu_position'     => null,
            'supports'         => array('title', 'editor', 'thumbnail', 'excerpt'),
            'menu_icon'         => 'dashicons-products',
        );

        register_post_type('shopify_product', $args);
    }

    public function add_meta_boxes() {
        add_meta_box(
            'shopify_product_meta',
            __('Shopify Product Details', 'shopify-products-display'),
            array($this, 'render_meta_box'),
            'shopify_product',
            'normal',
            'high'
        );
    }

    public function render_meta_box($post) {
        // Add nonce for security
        wp_nonce_field('shopify_product_meta_nonce', 'shopify_product_meta_nonce');

        // Get existing values
        $product_id = get_post_meta($post->ID, '_shopify_product_id', true);
        $price = get_post_meta($post->ID, '_shopify_product_price', true);
        $compare_at_price = get_post_meta($post->ID, '_shopify_product_compare_at_price', true);
        $vendor = get_post_meta($post->ID, '_shopify_product_vendor', true);
        $product_type = get_post_meta($post->ID, '_shopify_product_type', true);
        $tags = get_post_meta($post->ID, '_shopify_product_tags', true);
        $shopify_link = get_post_meta($post->ID, '_shopify_product_link', true);
        $variants = get_post_meta($post->ID, '_shopify_product_variants', true);

        // Display fields
        ?>
        <div class="shopify-product-meta-fields">
            <div class="meta-field">
                <label for="shopify_product_id"><?php _e('Shopify Product ID', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_id" name="shopify_product_id" value="<?php echo esc_attr($product_id); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_price"><?php _e('Price', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_price" name="shopify_product_price" value="<?php echo esc_attr($price); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_compare_at_price"><?php _e('Compare At Price', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_compare_at_price" name="shopify_product_compare_at_price" value="<?php echo esc_attr($compare_at_price); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_vendor"><?php _e('Vendor', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_vendor" name="shopify_product_vendor" value="<?php echo esc_attr($vendor); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_type"><?php _e('Product Type', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_type" name="shopify_product_type" value="<?php echo esc_attr($product_type); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_tags"><?php _e('Tags', 'shopify-products-display'); ?></label>
                <input type="text" id="shopify_product_tags" name="shopify_product_tags" value="<?php echo esc_attr($tags); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label for="shopify_product_link"><?php _e('Shopify Product Link', 'shopify-products-display'); ?></label>
                <input type="url" id="shopify_product_link" name="shopify_product_link" value="<?php echo esc_attr($shopify_link); ?>" class="widefat">
            </div>

            <div class="meta-field">
                <label><?php _e('Variants', 'shopify-products-display'); ?></label>
                <textarea id="shopify_product_variants" name="shopify_product_variants" class="widefat" rows="5"><?php echo esc_textarea($variants); ?></textarea>
                <p class="description"><?php _e('Enter variants as JSON data', 'shopify-products-display'); ?></p>
            </div>
        </div>
        <?php
    }

    public function save_meta_data($post_id) {
        // Check if nonce is set
        if (!isset($_POST['shopify_product_meta_nonce'])) {
            return;
        }

        // Verify nonce
        if (!wp_verify_nonce($_POST['shopify_product_meta_nonce'], 'shopify_product_meta_nonce')) {
            return;
        }

        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check user permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Save meta data
        $fields = array(
            'shopify_product_id',
            'shopify_product_price',
            'shopify_product_compare_at_price',
            'shopify_product_vendor',
            'shopify_product_type',
            'shopify_product_tags',
            'shopify_product_link',
            'shopify_product_variants'
        );

        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, '_' . $field, sanitize_text_field($_POST[$field]));
            }
        }
    }
}