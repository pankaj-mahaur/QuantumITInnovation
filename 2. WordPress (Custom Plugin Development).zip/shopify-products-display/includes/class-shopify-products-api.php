<?php
if (!defined('ABSPATH')) {
    exit;
}

class Shopify_Products_API {

    private $api_key;
    private $password;
    private $store_url;
    private $api_version;

    public function __construct() {
        // Initialize settings
        $this->init_settings();

        // Add admin menu
        add_action('admin_menu', array($this, 'add_admin_menu'));

        // Register settings
        add_action('admin_init', array($this, 'register_settings'));

        // Schedule product sync
        add_action('init', array($this, 'schedule_sync'));
        add_action('shopify_products_sync_hook', array($this, 'sync_products'));
    }

    private function init_settings() {
        $this->api_key = get_option('shopify_products_api_key');
        $this->password = get_option('shopify_products_password');
        $this->store_url = get_option('shopify_products_store_url');
        $this->api_version = get_option('shopify_products_api_version', '2024-01');
    }

    public function add_admin_menu() {
        add_submenu_page(
            'edit.php?post_type=shopify_product',
            __('Shopify Products Settings', 'shopify-products-display'),
            __('Settings', 'shopify-products-display'),
            'manage_options',
            'shopify_products_settings',
            array($this, 'render_settings_page')
        );
    }

    public function register_settings() {
        register_setting('shopify_products_settings_group', 'shopify_products_api_key');
        register_setting('shopify_products_settings_group', 'shopify_products_password');
        register_setting('shopify_products_settings_group', 'shopify_products_store_url');
        register_setting('shopify_products_settings_group', 'shopify_products_api_version');
        register_setting('shopify_products_settings_group', 'shopify_products_sync_interval');
    }

    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e('Shopify Products Settings', 'shopify-products-display'); ?></h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('shopify_products_settings_group'); ?>
                <?php do_settings_sections('shopify_products_settings_group'); ?>
                
                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><?php _e('Store URL', 'shopify-products-display'); ?></th>
                        <td>
                            <input type="text" name="shopify_products_store_url" value="<?php echo esc_attr(get_option('shopify_products_store_url')); ?>" class="regular-text" />
                            <p class="description"><?php _e('Your Shopify store URL (e.g., your-store.myshopify.com)', 'shopify-products-display'); ?></p>
                        </td>
                    </tr>
                    
                    <tr valign="top">
                        <th scope="row"><?php _e('API Key', 'shopify-products-display'); ?></th>
                        <td>
                            <input type="text" name="shopify_products_api_key" value="<?php echo esc_attr(get_option('shopify_products_api_key')); ?>" class="regular-text" />
                        </td>
                    </tr>
                    
                    <tr valign="top">
                        <th scope="row"><?php _e('Password', 'shopify-products-display'); ?></th>
                        <td>
                            <input type="password" name="shopify_products_password" value="<?php echo esc_attr(get_option('shopify_products_password')); ?>" class="regular-text" />
                        </td>
                    </tr>
                    
                    <tr valign="top">
                        <th scope="row"><?php _e('API Version', 'shopify-products-display'); ?></th>
                        <td>
                            <input type="text" name="shopify_products_api_version" value="<?php echo esc_attr(get_option('shopify_products_api_version', '2024-01')); ?>" class="regular-text" />
                            <p class="description"><?php _e('The Shopify API version to use', 'shopify-products-display'); ?></p>
                        </td>
                    </tr>
                    
                    <tr valign="top">
                        <th scope="row"><?php _e('Sync Interval', 'shopify-products-display'); ?></th>
                        <td>
                            <select name="shopify_products_sync_interval">
                                <?php
                                $intervals = array(
                                    'hourly' => __('Hourly', 'shopify-products-display'),
                                    'twicedaily' => __('Twice Daily', 'shopify-products-display'),
                                    'daily' => __('Daily', 'shopify-products-display'),
                                    'weekly' => __('Weekly', 'shopify-products-display'),
                                );
                                
                                $current_interval = get_option('shopify_products_sync_interval', 'daily');
                                
                                foreach ($intervals as $value => $label) {
                                    echo '<option value="' . esc_attr($value) . '" ' . selected($current_interval, $value, false) . '>' . esc_html($label) . '</option>';
                                }
                                ?>
                            </select>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button(); ?>
                
                <p>
                    <a href="<?php echo admin_url('admin-post.php?action=shopify_products_manual_sync'); ?>" class="button button-secondary">
                        <?php _e('Sync Products Now', 'shopify-products-display'); ?>
                    </a>
                </p>
            </form>
        </div>
        <?php
    }

    public function schedule_sync() {
        if (!wp_next_scheduled('shopify_products_sync_hook')) {
            $interval = get_option('shopify_products_sync_interval', 'daily');
            wp_schedule_event(time(), $interval, 'shopify_products_sync_hook');
        }
    }

    public function sync_products() {
        if (empty($this->api_key) || empty($this->password) || empty($this->store_url)) {
            error_log('Shopify Products: API credentials not set');
            return;
        }

        $products = $this->fetch_products();

        if ($products && is_array($products)) {
            foreach ($products as $product) {
                $this->create_or_update_product($product);
            }
        }
    }

    private function fetch_products() {
        $url = "https://{$this->api_key}:{$this->password}@{$this->store_url}/admin/api/{$this->api_version}/products.json";

        $response = wp_remote_get($url, array(
            'timeout' => 30,
        ));

        if (is_wp_error($response)) {
            error_log('Shopify Products API Error: ' . $response->get_error_message());
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['products'])) {
            return $data['products'];
        }

        return false;
    }

    private function create_or_update_product($product_data) {
        // Check if product exists by Shopify ID
        $existing_post = $this->get_post_by_shopify_id($product_data['id']);

        $post_data = array(
            'post_title'   => $product_data['title'],
            'post_content' => $product_data['body_html'],
            'post_excerpt' => $product_data['body_html'], // Using body_html as excerpt for simplicity
            'post_status'  => 'publish',
            'post_type'    => 'shopify_product',
        );

        if ($existing_post) {
            $post_data['ID'] = $existing_post->ID;
            $post_id = wp_update_post($post_data);
        } else {
            $post_id = wp_insert_post($post_data);
        }

        if ($post_id && !is_wp_error($post_id)) {
            // Save meta data
            update_post_meta($post_id, '_shopify_product_id', $product_data['id']);
            update_post_meta($post_id, '_shopify_product_price', $this->get_product_price($product_data));
            update_post_meta($post_id, '_shopify_product_compare_at_price', $this->get_compare_at_price($product_data));
            update_post_meta($post_id, '_shopify_product_vendor', $product_data['vendor']);
            update_post_meta($post_id, '_shopify_product_type', $product_data['product_type']);
            update_post_meta($post_id, '_shopify_product_tags', implode(', ', $product_data['tags']));
            update_post_meta($post_id, '_shopify_product_link', "https://{$this->store_url}/products/{$product_data['handle']}");
            update_post_meta($post_id, '_shopify_product_variants', json_encode($product_data['variants']));

            // Handle featured image
            if (!empty($product_data['images'])) {
                $this->set_featured_image($post_id, $product_data['images'][0]['src']);
            }

            return $post_id;
        }

        return false;
    }

    private function get_post_by_shopify_id($shopify_id) {
        $query = new WP_Query(array(
            'post_type' => 'shopify_product',
            'meta_key' => '_shopify_product_id',
            'meta_value' => $shopify_id,
            'posts_per_page' => 1,
        ));

        if ($query->have_posts()) {
            return $query->posts[0];
        }

        return false;
    }

    private function get_product_price($product_data) {
        if (!empty($product_data['variants'])) {
            return $product_data['variants'][0]['price'];
        }
        return '0.00';
    }

    private function get_compare_at_price($product_data) {
        if (!empty($product_data['variants'])) {
            return $product_data['variants'][0]['compare_at_price'] ?? '0.00';
        }
        return '0.00';
    }

    private function set_featured_image($post_id, $image_url) {
        // Check if image already exists
        $existing_id = $this->get_attachment_id_from_url($image_url);

        if ($existing_id) {
            set_post_thumbnail($post_id, $existing_id);
            return true;
        }

        // Download new image
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $tmp = download_url($image_url);

        if (is_wp_error($tmp)) {
            return false;
        }

        $file_array = array(
            'name' => basename($image_url),
            'tmp_name' => $tmp
        );

        $attachment_id = media_handle_sideload($file_array, $post_id);

        if (is_wp_error($attachment_id)) {
            @unlink($file_array['tmp_name']);
            return false;
        }

        set_post_thumbnail($post_id, $attachment_id);
        return true;
    }

    private function get_attachment_id_from_url($url) {
        global $wpdb;

        $query = $wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attached_file' AND meta_value LIKE %s",
            '%' . $wpdb->esc_like(basename($url))
        );

        $attachment_id = $wpdb->get_var($query);

        if ($attachment_id) {
            return $attachment_id;
        }

        // Also check the _wp_attachment_metadata for resized images
        $query = $wpdb->prepare(
            "SELECT post_id FROM $wpdb->postmeta WHERE meta_key = '_wp_attachment_metadata' AND meta_value LIKE %s",
            '%' . $wpdb->esc_like(basename($url)) . '%'
        );

        $attachment_id = $wpdb->get_var($query);

        return $attachment_id ?: false;
    }
}