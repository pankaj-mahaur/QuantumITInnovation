jQuery(document).ready(function($) {
    // Handle AJAX filtering
    $('.shopify-products-filters form').on('submit', function(e) {
        e.preventDefault();
        
        var formData = $(this).serialize();
        
        $.ajax({
            url: shopify_products_vars.ajaxurl,
            type: 'POST',
            data: {
                action: 'shopify_products_filter',
                nonce: shopify_products_vars.nonce,
                data: formData
            },
            beforeSend: function() {
                $('.shopify-products-container').addClass('loading');
            },
            success: function(response) {
                if (response.success) {
                    $('.shopify-products-container').html(response.data.html);
                    
                    // Update pagination if needed
                    if (response.data.max_num_pages) {
                        // You can implement pagination update logic here
                    }
                }
            },
            complete: function() {
                $('.shopify-products-container').removeClass('loading');
            }
        });
    });
    
    // Handle pagination
    $(document).on('click', '.shopify-products-pagination a', function(e) {
        e.preventDefault();
        
        var page = $(this).attr('href').match(/paged=(\d+)/)[1];
        
        $.ajax({
            url: shopify_products_vars.ajaxurl,
            type: 'POST',
            data: {
                action: 'shopify_products_filter',
                nonce: shopify_products_vars.nonce,
                paged: page
            },
            beforeSend: function() {
                $('.shopify-products-container').addClass('loading');
            },
            success: function(response) {
                if (response.success) {
                    $('.shopify-products-container').html(response.data.html);
                    $('html, body').animate({
                        scrollTop: $('.shopify-products-container').offset().top - 20
                    }, 500);
                }
            },
            complete: function() {
                $('.shopify-products-container').removeClass('loading');
            }
        });
    });
});